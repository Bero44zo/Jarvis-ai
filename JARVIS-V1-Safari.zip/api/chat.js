import OpenAI from "openai";

const client = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

const instructions = `
Du bist JARVIS, ein persönlicher KI-Allrounder.
Antworte standardmäßig auf Deutsch, außer der Nutzer bittet um eine andere Sprache.
Sei präzise, freundlich und praktisch. Erkläre schwierige Dinge verständlich.
Wenn Informationen fehlen, frage kurz nach, statt etwas zu erfinden.
Behaupte niemals, eine externe Aktion ausgeführt zu haben, wenn du kein entsprechendes Werkzeug hast.
`;

export default async function handler(req, res) {
  if (req.method !== "POST") return res.status(405).json({ error: "Nur POST ist erlaubt." });

  try {
    const incoming = Array.isArray(req.body?.messages) ? req.body.messages : [];
    const messages = incoming
      .filter(m => (m?.role === "user" || m?.role === "assistant") && typeof m?.content === "string")
      .slice(-30)
      .map(m => ({ role: m.role, content: m.content.slice(0, 12000) }));

    if (!messages.length) return res.status(400).json({ error: "Keine Nachricht erhalten." });

    const response = await client.responses.create({
      model: process.env.OPENAI_MODEL || "gpt-5.5",
      instructions,
      input: messages
    });

    return res.status(200).json({ content: response.output_text || "Keine Antwort erhalten." });
  } catch (error) {
    console.error(error);
    return res.status(500).json({ error: "JARVIS konnte die Anfrage nicht verarbeiten. Prüfe API-Key und Modell." });
  }
}