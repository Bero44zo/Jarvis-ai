# JARVIS V1 – Safari Edition

Diese Version ist für Deployment auf Vercel vorbereitet.

## Wichtig
Der OpenAI API-Key gehört ausschließlich in die Server-Umgebungsvariable `OPENAI_API_KEY`.
Niemals in `index.html` eintragen.

## Deployment
1. Projekt in ein GitHub-Repository hochladen.
2. Auf Vercel ein neues Projekt aus diesem Repository erstellen.
3. Environment Variable anlegen:
   OPENAI_API_KEY = dein API-Key
4. Optional:
   OPENAI_MODEL = gpt-5.5
5. Deploy.
6. Die erzeugte `vercel.app`-Adresse in Safari öffnen.

Die OpenAI Responses API wird serverseitig verwendet.
